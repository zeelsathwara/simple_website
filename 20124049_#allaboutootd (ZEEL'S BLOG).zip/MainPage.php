<!DOCTYPE html>

<html>

<head>

    <title>#allaboutootd | ZEEL'S BLOG</title>

    <link rel = 'stylesheet' type = 'text/css' href = 'MainStyle.css'>

    <script>
        function click_button()
        {
            window.location.href = "default.asp";
        }
    </script>

</head>

<body bgcolor = "#FDEBEB" align = "center">

    <div class = "div1">
        <a href = "https://www.facebook.com/" target = "_blank">FACEBOOK</a> &nbsp;&nbsp;
        <a href = "https://in.pinterest.com/" target = "_blank">PINTEREST</a> &nbsp;&nbsp;
        <a href = "https://www.instagram.com/" target = "_blank">INSTAGRAM</a> &nbsp;&nbsp;
        <a href = "https://twitter.com/?lang=en" target = "_blank">TWITTER</a> &nbsp;&nbsp;
        <a href = "https://www.bloglovin.com/" target = "_blank">BLOGLOVIN'</a> &nbsp;&nbsp;
    </div>

    <font face = "Pristina"><h1 style="color: #C93756">#allaboutootd</h1></font> 
    
    <h2>----------</h2>
    <a style = "color: #262220" href = "MainPage.php" target = "_blank">BLOG</a> &nbsp;&nbsp;
    <a style = "color: #262220" href = "default.asp" target = "_blank">SHOP</a> &nbsp;&nbsp;
    <a style = "color: #262220" href = "ContactPage.php" target = "_blank">CONTACT</a> &nbsp;&nbsp;
    <h2>----------</h2>

    <img src = "Image2.png" alt = "Intro to the Blog" width = 700px height = 400px hspace = 20>  
    &nbsp;&nbsp;
    <img src = "Image3.png" alt = "Self Introduction" width = 300px height = 400px hspace = 20>

    <div class = "container">
        <div class = "block">
            <font face = "Pristina"><h2>---WINTER CLOTHING---</h2></font> 
            <img src = "Image4.png">
            <h3>As winter season is here we need to be warm and cozy but yet stylish. We need to wear thick furry clothes which keep us warm, so sweater, jackets, sweatshirts, cardigan, etc. are preferable options to wear in winter.</h3> 
            <p>Published on 30 June 2021</p>
            <button class = "button" onclick = "click_button()">READ MORE...</button>
            <br><br>
            <button class = "button" onclick = "click_button()">VIEW MORE BLOGS!</button>
        </div>
    </div>

    <div class="div1">......................................................</div>

</body>

</html>