<!DOCTYPE html>

<html>

<head>
    
    <title>CONTACT | ZEEL'S BLOG</title>

    <link rel = 'stylesheet' type = 'text/css' href = 'MainStyle.css'>

    <script>
        function click_button()
        {
            alert("Thank You for Subscribing. Please wait till the page gets loaded.");
        }
    </script>

</head>

<body bgcolor = "#FDEBEB" align = "center">

    <div class = "div1">
        <a href = "https://www.facebook.com/" target = "_blank">FACEBOOK</a> &nbsp;&nbsp;
        <a href = "https://in.pinterest.com/" target = "_blank">PINTEREST</a> &nbsp;&nbsp;
        <a href = "https://www.instagram.com/" target = "_blank">INSTAGRAM</a> &nbsp;&nbsp;
        <a href = "https://twitter.com/?lang=en" target = "_blank">TWITTER</a> &nbsp;&nbsp;
        <a href = "https://www.bloglovin.com/" target = "_blank">BLOGLOVIN'</a> &nbsp;&nbsp;
    </div>

    <font face = "Pristina"><h1 style="color: #C93756">#allaboutootd</h1></font>
    
    <h2>----------</h2>
    <a style = "color: #262220" href = "default.asp" target = "_blank">BLOG</a> &nbsp;&nbsp;
    <a style ="color: #262220" href = "default.asp" target = "_blank">SHOP</a> &nbsp;&nbsp;
    <a style = "color: #262220" href = "ContactPage.php" target = "_blank">CONTACT</a> &nbsp;&nbsp;
    <h2>----------</h2>

<br>

<font face = "pristina" style = "color: #A15C38"><h1>I love meeting new people!</h1></font>

<br>

<form action = "DisplayingData.php" target = "_blank" method = "post">

<table cellpadding = "5" cellspacing = "0" width = "50%" height = "100%" bgcolor = "#E4C2C1" align = "center">

<tr bgcolor = "#B6666F" align = "center">
  <td colspan = 2>
  	<font size = 4 color = "white">
          <b><h2>---SUBSCRIBE---</h2></b>
          <br>
          <b><h2>GET THE LATEST INFO!</h2></b>
    </font>
  </td>
</tr>

<tr>
  <td><b>Name</b></td>
  <td><input type = "text" name = "name" id = "name" size = "30">
  </td>
</tr>

<tr>
  <td><b>Email</b></td>
  <td>
    <input type = "text" name = "email" id = "email" size = "30">
  </td>
</tr>

<tr bgcolor = "#B6666F" align = "center">
  <td>
  </td>
  <td>
  <input class = "button" type = "submit" name = "submit" onload = "click_button()" value = "SUBSCRIBE!">
  </td>
</tr>

</table>

<div class="div1">......................................................</div>

</body>

</html>