<!DOCTYPE html>

<html>

    <head>

        <title> THANK YOU! | ZEEL'S BLOG </title>

        <link rel = 'stylesheet' type = 'text/css' href = 'MainStyle.css'>

        <script>
            function myfunc()
            {
                window.location.href = "http://localhost/phpmyadmin/index.php?route=/sql&server=1&db=zeel%27s_blog&table=subscribe_data&pos=0";
            }
            function clickbutton()
            {
                window.location.href = "MainPage.php";
            }
        </script>

</head>

<body bgcolor = "#FDEBEB">

<center>

<?php

    include("ConnectingDatabase.php");

    echo("<br><br><br><br><br> <h1> Thank You For Subscribing! </h1> <br>");

?>

<button class = "button" onclick = "clickbutton()" target="_blank">BACK TO HOME</button>
 
</center>

</body>
 
</html>