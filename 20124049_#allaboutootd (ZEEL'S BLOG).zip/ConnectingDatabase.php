<!DOCTYPE html>

<html>

<head>
    
    <title>CONTACT | ZEEL'S BLOG</title>

    <link rel = 'stylesheet' type = 'text/css' href = 'MainStyle.css'>

    <script>
        function click_button()
        {
            alert("Thank You for Subscribing. Please wait till the page gets loaded.");
        }
    </script>

</head>

<body bgcolor = "#FDEBEB" align = "center">

    <div class = "div1">
        <a href = "https://www.facebook.com/" target = "_blank">FACEBOOK</a> &nbsp;&nbsp;
        <a href = "https://in.pinterest.com/" target = "_blank">PINTEREST</a> &nbsp;&nbsp;
        <a href = "https://www.instagram.com/" target = "_blank">INSTAGRAM</a> &nbsp;&nbsp;
        <a href = "https://twitter.com/?lang=en" target = "_blank">TWITTER</a> &nbsp;&nbsp;
        <a href = "https://www.bloglovin.com/" target = "_blank">BLOGLOVIN'</a> &nbsp;&nbsp;
    </div>

    <font face = "Pristina"><h1 style="color: #C93756">#allaboutootd</h1></font>
    
    <h2>----------</h2>
    <a style = "color: #262220" href = "default.asp" target = "_blank">BLOG</a> &nbsp;&nbsp;
    <a style ="color: #262220" href = "default.asp" target = "_blank">SHOP</a> &nbsp;&nbsp;
    <a style = "color: #262220" href = "ContactPage.php" target = "_blank">CONTACT</a> &nbsp;&nbsp;
    <h2>----------</h2>

<?php 
 $servername = "localhost"; 
 $username = "root"; 
 $password = ""; 
 $dbname = "zeel's_blog"; 
 try
 {
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    echo("<b> Successful In Connection. </b>");
 }
 catch(MySQLi_Sql_Exception $ex)
 {
    echo("<b> Error In Connection. </b>");
 }
 if(isset($_POST['submit']))
 {
    $name=$_POST['name'];
    $email=$_POST['email'];
    $register_query = "INSERT INTO `subscribe_data`(`Name`, `Email`) VALUES ('$name','$email')";
  try
  {
      $register_result = mysqli_query($conn, $register_query);
      if($register_result)
      {
        if(mysqli_affected_rows($conn)>0)
        {
            echo("<b> Successfully Subscribed. </b>\n<br><br>");
        }
        else
        {
            echo("<b> Error In Subscribing. </b>\n<br><br>");
        }
      }
  }
  catch(Exception $ex)
  {
    echo("Error".$ex->getMessage());
  }
 }
?>

</body>

</html>